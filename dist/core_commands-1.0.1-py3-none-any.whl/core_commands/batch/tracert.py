from ..bin.baxh import baxh

def tracert(arguments=None):
    return baxh("tracert",arguments)