from ..bin.baxh import baxh

def compact(arguments=None):
     return baxh("compact",arguments)