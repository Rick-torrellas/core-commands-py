from ..bin.baxh import baxh

def move(arguments=None):
    return baxh("move",arguments)