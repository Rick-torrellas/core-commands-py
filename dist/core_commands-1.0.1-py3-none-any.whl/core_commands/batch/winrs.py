from ..bin.baxh import baxh

def winrs(arguments=None):
    return baxh("winrs",arguments)