from ..bin.baxh import baxh

def CMD(arguments=None):
    # https://ss64.com/nt/cmd.html
    return baxh("cmd",arguments)
    pass