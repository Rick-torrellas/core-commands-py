from ..bin.baxh import baxh

def getmac(arguments=None):
     return baxh("getmac",arguments)