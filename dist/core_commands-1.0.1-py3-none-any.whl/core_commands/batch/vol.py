from ..bin.baxh import baxh

def vol(arguments=None):
    return baxh("vol",arguments)