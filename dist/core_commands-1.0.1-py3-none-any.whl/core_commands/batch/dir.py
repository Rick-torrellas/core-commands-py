from ..bin.baxh import baxh

def dir(arguments = None):
    return baxh("dir",arguments)