from ..bin.cmd import cmd

def rasphone(arguments=None):
    return cmd("rasphone",arguments)