from ..bin.cmd import cmd

def esentutl(arguments=None):
     return cmd("esentutl",arguments)