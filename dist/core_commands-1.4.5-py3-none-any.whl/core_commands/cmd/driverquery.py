from ..bin.cmd import cmd

def driverquery(arguments=None):
     return cmd("driverquery",arguments)