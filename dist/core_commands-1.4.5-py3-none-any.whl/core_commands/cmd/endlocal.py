from ..bin.cmd import cmd

def endlocal(arguments=None):
     return cmd("endlocal",arguments)