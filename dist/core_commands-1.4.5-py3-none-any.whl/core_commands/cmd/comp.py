from ..bin.cmd import cmd

def comp(arguments=None):
     return cmd("comp",arguments)