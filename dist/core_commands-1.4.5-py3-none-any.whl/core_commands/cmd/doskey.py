from ..bin.cmd import cmd

def doskey(arguments=None):
     return cmd("doskey",arguments)