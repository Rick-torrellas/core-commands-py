from ..bin.cmd import cmd

def logman(arguments=None):
     return cmd("logman",arguments)