from ..bin.cmd import cmd

def icacls(arguments=None):
     return cmd("icacls",arguments)