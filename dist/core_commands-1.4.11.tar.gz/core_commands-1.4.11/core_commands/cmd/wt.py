from ..bin.cmd import cmd

def wt(arguments=None):
    return cmd("wt",arguments)