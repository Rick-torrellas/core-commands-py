from ..bin.cmd import cmd

def chcp(arguments=None):
     return cmd("chcp",f"{arguments}")