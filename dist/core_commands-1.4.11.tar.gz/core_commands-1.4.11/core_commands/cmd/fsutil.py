from ..bin.cmd import cmd

def fsutil(arguments=None):
     return cmd("fsutil",arguments)