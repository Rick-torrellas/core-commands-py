from ..bin.cmd import cmd

def qwinsta(arguments=None):
    return cmd("qwinsta",arguments)