from ..bin.cmd import cmd

def change(arguments = None):
     return cmd("change",f"{arguments}")