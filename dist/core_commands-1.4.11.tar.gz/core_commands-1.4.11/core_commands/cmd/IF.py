from ..bin.cmd import cmd

def IF(arguments=None):
     return cmd("if",arguments)