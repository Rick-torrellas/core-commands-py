from ..bin.baxh import baxh

def date(arguments=None):
    return baxh('date',arguments)