from ..bin.baxh import baxh

def slmgr(arguments=None):
    return baxh("slmgr",arguments)