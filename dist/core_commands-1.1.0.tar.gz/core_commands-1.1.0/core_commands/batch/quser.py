from ..bin.baxh import baxh

def quser(arguments=None):
    return baxh("quser",arguments)