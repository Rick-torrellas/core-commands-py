from ..bin.baxh import baxh

def fltmc(arguments=None):
     return baxh("fltmc",arguments)