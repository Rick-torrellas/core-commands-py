from ..bin.baxh import baxh

def rd(arguments=None):
    return baxh("rd",arguments)