from ..bin.baxh import baxh

def chkntfs(arguments=None):
     return baxh("chkntfs",arguments)