from ..bin.baxh import baxh

def winrm(arguments=None):
    return baxh("winrm",arguments)