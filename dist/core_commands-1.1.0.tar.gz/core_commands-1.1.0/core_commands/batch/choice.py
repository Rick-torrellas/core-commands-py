from ..bin.baxh import baxh

def choice(arguments=None):
     return baxh("choice",arguments)