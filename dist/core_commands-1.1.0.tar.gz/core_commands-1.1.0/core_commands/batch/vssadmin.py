from ..bin.baxh import baxh

def vssadmin(arguments=None):
    return baxh("vssadmin",arguments)