from ..bin.baxh import baxh

def where(arguments = None):
    return baxh("where",arguments)