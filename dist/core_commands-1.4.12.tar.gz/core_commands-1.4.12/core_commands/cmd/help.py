from ..bin.cmd import cmd

def help(arguments=None):
     return cmd("help",arguments)