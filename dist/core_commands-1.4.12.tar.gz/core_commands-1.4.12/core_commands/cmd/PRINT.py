from ..bin.cmd import cmd

def PRINT(arguments=None):
    return cmd("print",arguments)