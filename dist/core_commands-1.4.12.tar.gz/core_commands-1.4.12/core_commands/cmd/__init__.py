# from .cmd import ping
from ..bin.cmd import cmd
from .ping import ping

__all__ = ['ping',"cmd"]