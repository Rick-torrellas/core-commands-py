from ..bin.cmd import cmd

def waitfor(arguments=None):
    return cmd(arguments)