from ..bin.cmd import cmd

def vol(arguments=None):
    return cmd("vol",arguments)