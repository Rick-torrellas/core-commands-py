from .command_cmd import command_cmd

def wpr(arguments):
    return command_cmd(f"wpr {arguments}")