from ..bin.baxh import baxh

def mbr2gpt(arguments=None):
    return baxh("mbr2gpt",arguments)