from ..bin.baxh import baxh

def fc(arguments=None):
     return baxh("fc",arguments)