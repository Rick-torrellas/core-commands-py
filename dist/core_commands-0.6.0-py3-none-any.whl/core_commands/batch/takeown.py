from ..bin.baxh import baxh

def takeown(arguments=None):
    return baxh("takeown",arguments)