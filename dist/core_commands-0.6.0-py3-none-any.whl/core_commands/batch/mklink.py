from ..bin.baxh import baxh

def mklink(arguments=None):
    return baxh("mklink",arguments)