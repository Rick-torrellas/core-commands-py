from ..bin.baxh import baxh

def setspn(arguments=None):
    return baxh("setspn",arguments)