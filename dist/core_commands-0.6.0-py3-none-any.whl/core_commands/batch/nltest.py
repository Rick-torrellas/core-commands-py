from ..bin.baxh import baxh

def nltest(arguments=None):
    return baxh("nltest",arguments)