from ..bin.baxh import baxh

def waitfor(arguments=None):
    return baxh(arguments)