from ..bin.baxh import baxh

def mountvol(arguments=None):
    return baxh("mountvol",arguments)