from ..bin.baxh import baxh

def changepk(arguments=None):
     return baxh("changepk",f'{arguments}')