from ..bin.baxh import baxh

def tsdiscon(arguments=None):
    return baxh("tsdiscon",arguments)