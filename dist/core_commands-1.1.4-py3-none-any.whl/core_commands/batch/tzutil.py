from ..bin.baxh import baxh

def tzutil(arguments=None):
    return baxh("tzutil",arguments)