from ..bin.baxh import baxh

def setlocal(arguments=None):
    return baxh("setlocal",arguments)