from ..bin.baxh import baxh

def gpresult(arguments=None):
     return baxh("gpresult",arguments)