from ..bin.baxh import baxh

def rundll32(arguments=None):
    return baxh("rundll32",arguments)