from ..bin.baxh import baxh

def sfc(arguments=None):
    return baxh("sfc",arguments)