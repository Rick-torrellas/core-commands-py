from ..bin.baxh import baxh

def qappsrb(arguments=None):
    return baxh("gappsrb",arguments)