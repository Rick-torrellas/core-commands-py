from ..bin.baxh import baxh

def logman(arguments=None):
     return baxh("logman",arguments)