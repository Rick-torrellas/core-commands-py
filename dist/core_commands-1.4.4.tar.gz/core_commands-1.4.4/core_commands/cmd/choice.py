from ..bin.cmd import cmd

def choice(arguments=None):
     return cmd("choice",arguments)