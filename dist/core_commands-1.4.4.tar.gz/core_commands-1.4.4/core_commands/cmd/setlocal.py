from ..bin.cmd import cmd

def setlocal(arguments=None):
    return cmd("setlocal",arguments)