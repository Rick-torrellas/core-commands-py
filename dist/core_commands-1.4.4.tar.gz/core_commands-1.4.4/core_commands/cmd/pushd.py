from ..bin.cmd import cmd

def pushd(arguments=None):
    return cmd("pushd",arguments)