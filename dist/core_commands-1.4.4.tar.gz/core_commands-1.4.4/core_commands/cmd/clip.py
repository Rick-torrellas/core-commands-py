from ..bin.cmd import cmd

def clip(arguments=None):
     return cmd("clip",arguments)