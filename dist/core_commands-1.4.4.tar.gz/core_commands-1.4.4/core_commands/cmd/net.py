from ..bin.cmd import cmd

def net(arguments=None):
    return cmd("net",arguments)