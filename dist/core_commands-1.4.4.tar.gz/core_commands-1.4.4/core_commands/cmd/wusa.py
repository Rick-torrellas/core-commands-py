from ..bin.cmd import cmd

def wusa(arguments=None):
    return cmd("wusa",arguments)
    