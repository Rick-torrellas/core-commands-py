from ..bin.cmd import cmd

def regini(arguments=None):
    return cmd("regini",arguments)