from ..bin.cmd import cmd

def fc(arguments=None):
     return cmd("fc",arguments)