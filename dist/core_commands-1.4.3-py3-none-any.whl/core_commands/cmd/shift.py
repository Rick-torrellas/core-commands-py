from ..bin.cmd import cmd

def shift(arguments=None):
    return cmd("shift",arguments)