from ..bin.cmd import cmd

def systeminfo(arguments=None):
    return cmd("systeminfo",arguments)