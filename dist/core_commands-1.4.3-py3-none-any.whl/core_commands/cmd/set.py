from ..bin.cmd import cmd

def set(arguments=None):
    return cmd("set",arguments)