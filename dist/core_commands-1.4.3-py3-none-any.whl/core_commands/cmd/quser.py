from ..bin.cmd import cmd

def quser(arguments=None):
    return cmd("quser",arguments)