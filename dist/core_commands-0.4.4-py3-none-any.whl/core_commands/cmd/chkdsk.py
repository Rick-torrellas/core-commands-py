from .command_cmd import basic_execution

def chkdsk(arguments):
     return basic_execution("chkdsk",arguments)