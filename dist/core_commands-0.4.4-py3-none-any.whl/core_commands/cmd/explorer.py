from .command_cmd import basic_execution

def explorer(arguments):
     return basic_execution("explorer",arguments)