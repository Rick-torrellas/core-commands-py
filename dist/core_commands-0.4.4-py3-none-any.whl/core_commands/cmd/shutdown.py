from .command_cmd import basic_execution

def shutdown(arguments):
    return basic_execution("shutdown",arguments)