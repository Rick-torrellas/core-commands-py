from .command_cmd import basic_execution

def subst(arguments = False):
    return basic_execution("subst",arguments)