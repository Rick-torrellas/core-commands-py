from .command_cmd import basic_execution

def rundll32(arguments):
    return basic_execution("rundll32",arguments)