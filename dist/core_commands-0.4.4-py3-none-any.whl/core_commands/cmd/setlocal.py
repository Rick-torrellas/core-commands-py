from .command_cmd import basic_execution

def setlocal(arguments):
    return basic_execution("setlocal",arguments)