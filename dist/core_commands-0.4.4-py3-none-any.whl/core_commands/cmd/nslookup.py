from .command_cmd import basic_execution

def nslookup(arguments):
    return basic_execution("nslookup",arguments)