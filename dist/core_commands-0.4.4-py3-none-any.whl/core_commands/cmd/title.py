from .command_cmd import basic_execution

def title(arguments):
    return basic_execution("title",arguments)