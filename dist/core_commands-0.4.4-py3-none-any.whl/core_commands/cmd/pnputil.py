from .command_cmd import basic_execution

def pnputil(arguments):
    return basic_execution("pnputil",arguments)