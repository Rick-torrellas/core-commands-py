from .command_cmd import basic_execution

def path(arguments):
    return basic_execution("path",arguments)