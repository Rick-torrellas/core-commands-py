from .command_cmd import basic_execution

def eventcreate(arguments):
     return basic_execution("eventcreate",arguments)