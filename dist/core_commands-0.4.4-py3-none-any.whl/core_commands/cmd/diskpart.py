from .command_cmd import basic_execution

def diskpart(arguments):
     return basic_execution("diskpart",arguments)