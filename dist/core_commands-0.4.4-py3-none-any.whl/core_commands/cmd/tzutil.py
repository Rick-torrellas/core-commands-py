from .command_cmd import basic_execution

def tzutil(arguments):
    return basic_execution("tzutil",arguments)