from .command_cmd import basic_execution

def vol(arguments):
    return basic_execution("vol",arguments)