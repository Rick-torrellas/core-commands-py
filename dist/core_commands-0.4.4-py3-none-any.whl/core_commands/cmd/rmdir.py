from .command_cmd import basic_execution

def rmdir(arguments):
    return basic_execution("rmdir",arguments)