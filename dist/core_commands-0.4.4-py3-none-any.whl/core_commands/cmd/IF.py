from .command_cmd import basic_execution

def IF(arguments):
     return basic_execution("if",arguments)