from .command_cmd import basic_execution

def cmdkey(arguments):
     return basic_execution("cmdkey",arguments)