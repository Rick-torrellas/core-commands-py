from .command_cmd import basic_execution

def displayswitch(arguments):
     return basic_execution("displayswitch",arguments)