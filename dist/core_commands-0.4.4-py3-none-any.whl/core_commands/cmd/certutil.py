from .command_cmd import basic_execution

def certutil(arguments):
     return basic_execution("certutil",arguments)