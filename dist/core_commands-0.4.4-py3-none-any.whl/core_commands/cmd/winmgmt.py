from .command_cmd import basic_execution

def winmgmt(arguments = False):
    return basic_execution("winmgmt",arguments)