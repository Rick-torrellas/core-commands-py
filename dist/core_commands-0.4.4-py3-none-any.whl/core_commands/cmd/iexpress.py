from .command_cmd import basic_execution

def iexpress(arguments):
     return basic_execution("iexpress",arguments)