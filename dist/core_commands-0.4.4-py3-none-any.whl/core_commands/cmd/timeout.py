from .command_cmd import basic_execution

def timeout(arguments):
    return basic_execution("timeout",arguments)