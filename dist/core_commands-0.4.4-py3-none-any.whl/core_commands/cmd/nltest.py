from .command_cmd import basic_execution

def nltest(arguments):
    return basic_execution("nltest",arguments)