from .command_cmd import basic_execution

def change(arguments):
     return basic_execution("change",arguments)