from .command_cmd import basic_execution

def nbtstat(arguments):
    return basic_execution("nbtstat",arguments)

