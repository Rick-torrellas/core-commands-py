from ..bin.cmd import cmd

def where(arguments = None):
    return cmd("where",arguments)