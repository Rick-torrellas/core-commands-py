from ..bin.cmd import cmd

def diskpart(arguments=None):
     return cmd("diskpart",arguments)