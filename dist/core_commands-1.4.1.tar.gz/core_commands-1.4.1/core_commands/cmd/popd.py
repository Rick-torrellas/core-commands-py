from ..bin.cmd import cmd

def popd(arguments=None):
    return cmd("popd",arguments)