from ..bin.cmd import cmd

def setspn(arguments=None):
    return cmd("setspn",arguments)