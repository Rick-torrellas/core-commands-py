from ..bin.cmd import cmd

def sfc(arguments=None):
    return cmd("sfc",arguments)