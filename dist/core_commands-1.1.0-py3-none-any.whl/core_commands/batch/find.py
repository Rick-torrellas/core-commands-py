from ..bin.baxh import baxh

def find(arguments=None):
     return baxh("find",arguments)