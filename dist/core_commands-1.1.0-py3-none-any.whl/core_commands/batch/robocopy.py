from ..bin.baxh import baxh

def robocopy(arguments=None):
    return baxh("robocopy",arguments)