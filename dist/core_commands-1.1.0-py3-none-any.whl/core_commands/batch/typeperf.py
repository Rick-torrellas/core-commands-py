from ..bin.baxh import baxh

def typeperf(arguments=None):
    return baxh("typeperf",arguments)