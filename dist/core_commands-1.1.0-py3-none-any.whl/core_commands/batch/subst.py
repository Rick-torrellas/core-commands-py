from ..bin.baxh import baxh

def subst(arguments=None):
    return baxh("subst",arguments)