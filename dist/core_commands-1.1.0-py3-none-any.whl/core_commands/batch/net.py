from ..bin.baxh import baxh

def net(arguments=None):
    return baxh("net",arguments)