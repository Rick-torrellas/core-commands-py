from ..bin.cmd import cmd

def timeout(arguments=None):
    return cmd("timeout",arguments)