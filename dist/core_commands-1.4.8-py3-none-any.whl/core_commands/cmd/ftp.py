from ..bin.cmd import cmd

def ftp(arguments=None):
     return cmd("ftp",arguments)