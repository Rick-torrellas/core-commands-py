from ..bin.cmd import cmd

def pktmon(arguments=None):
    return cmd("pktmon",arguments)