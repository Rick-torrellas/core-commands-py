from ..bin.cmd import cmd

def logoff(arguments=None):
    return cmd("logoff",arguments)