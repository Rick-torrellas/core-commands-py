from ..bin.cmd import cmd

def winrs(arguments=None):
    return cmd("winrs",arguments)