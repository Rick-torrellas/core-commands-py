from ..bin.cmd import cmd

def dir(arguments = None):
    return cmd("dir",arguments)