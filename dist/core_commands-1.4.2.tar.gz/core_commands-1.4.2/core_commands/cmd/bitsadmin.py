from ..bin.cmd import cmd

# TODO: profundo
def bitsadmin(arguments = None):
    return cmd(f"bitsadmin",f"{arguments}")