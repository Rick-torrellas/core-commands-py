from ..bin.cmd import cmd

def DEL(arguments=None):
    return cmd('del',arguments)
