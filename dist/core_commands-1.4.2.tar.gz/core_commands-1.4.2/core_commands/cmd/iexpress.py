from ..bin.cmd import cmd

def iexpress(arguments=None):
     return cmd("iexpress",arguments)