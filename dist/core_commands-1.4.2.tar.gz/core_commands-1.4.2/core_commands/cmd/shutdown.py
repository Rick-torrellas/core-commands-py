from ..bin.cmd import cmd

def shutdown(arguments=None):
    return cmd("shutdown",arguments)