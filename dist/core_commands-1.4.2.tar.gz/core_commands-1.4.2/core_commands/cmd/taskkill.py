from ..bin.cmd import cmd

def taskkill(arguments=None):
    return cmd("taskkill",arguments)