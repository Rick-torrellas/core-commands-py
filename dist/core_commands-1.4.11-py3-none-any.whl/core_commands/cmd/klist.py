from ..bin.cmd import cmd

def klist(arguments=None):
     return cmd("klist",arguments)