from ..bin.cmd import cmd

def gpupdate(arguments=None):
     return cmd("gpupdate",arguments)