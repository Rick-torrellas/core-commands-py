from ..bin.cmd import cmd

def certreq(arguments =None):
     return cmd("certreq",f'{arguments}') 