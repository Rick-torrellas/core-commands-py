from ..bin.cmd import cmd

def eventcreate(arguments=None):
     return cmd("eventcreate",arguments)