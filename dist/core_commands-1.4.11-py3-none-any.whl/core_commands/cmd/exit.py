from ..bin.cmd import cmd

def exit(arguments=None):
     return cmd("exit",arguments)