from ..bin.cmd import cmd

def whoami(arguments = None):
    return cmd("whoami",arguments)
