from ..bin.cmd import cmd

def reset(arguments=None):
    return cmd("reset",arguments)