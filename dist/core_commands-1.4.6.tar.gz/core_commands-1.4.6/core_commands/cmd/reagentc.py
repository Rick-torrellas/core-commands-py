from ..bin.cmd import cmd

def reagentc(arguments=None):
    return cmd("reagentc",arguments)