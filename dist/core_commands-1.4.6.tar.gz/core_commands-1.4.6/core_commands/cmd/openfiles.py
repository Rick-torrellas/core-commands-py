from ..bin.cmd import cmd

def openfiles(arguments=None):
    return cmd("openfiles",arguments)