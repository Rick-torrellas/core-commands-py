from ..bin.cmd import cmd

def subst(arguments=None):
    return cmd("subst",arguments)