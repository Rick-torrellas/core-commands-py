from ..bin.cmd import cmd

def msg(arguments=None):
    return cmd("msg",arguments)