from ..bin.cmd import cmd

def changepk(arguments=None):
     return cmd("changepk",f'{arguments}')