from ..bin.cmd import cmd

def cls(arguments=None):
    baxh("cls",arguments)