from src.cmd.functions import mkdir

mkdir("nalga")