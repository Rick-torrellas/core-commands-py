from ..bin.baxh import baxh

def rasdial(arguments=None):
    return baxh("rasdial",arguments)