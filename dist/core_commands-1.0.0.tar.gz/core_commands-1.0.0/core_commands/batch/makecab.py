from ..bin.baxh import baxh

def makecab(arguments=None):
    return baxh("makecab",arguments)