from ..bin.baxh import baxh

def regsvr32(arguments=None):
    return baxh("regsvr32",arguments)