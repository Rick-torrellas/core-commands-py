from ..bin.baxh import baxh

def scriptrunner(arguments=None):
    return baxh("scriptrunner",arguments)