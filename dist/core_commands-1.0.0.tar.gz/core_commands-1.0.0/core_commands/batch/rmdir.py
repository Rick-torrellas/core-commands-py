from ..bin.baxh import baxh

def rmdir(arguments=None):
    return baxh("rmdir",arguments)