from .cd import cd

def chdir(pathname,arguments = ""):
    """
    Change Directory - Select a Folder (and drive)
    """
    return cd(pathname,arguments)