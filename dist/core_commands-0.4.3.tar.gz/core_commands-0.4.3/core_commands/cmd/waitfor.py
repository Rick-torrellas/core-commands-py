from .command_cmd import command_cmd

def waitfor(arguments):
    return command_cmd(arguments)