from .command_cmd import command_cmd
from .dir import dir
from .mkdir import mkdir

def cmd():
    # https://ss64.com/nt/cmd.html
    pass