from ..bin.baxh import baxh

def msg(arguments=None):
    return baxh("msg",arguments)