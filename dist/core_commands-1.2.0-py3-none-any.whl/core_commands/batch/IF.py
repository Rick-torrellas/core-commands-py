from ..bin.baxh import baxh

def IF(arguments=None):
     return baxh("if",arguments)