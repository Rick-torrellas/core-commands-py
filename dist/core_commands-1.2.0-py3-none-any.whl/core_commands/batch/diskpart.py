from ..bin.baxh import baxh

def diskpart(arguments=None):
     return baxh("diskpart",arguments)