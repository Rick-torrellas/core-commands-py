from ..bin.baxh import baxh

def msinfo32(arguments=None):
    return baxh('msinfo32',arguments)