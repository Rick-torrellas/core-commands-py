from ..bin.baxh import baxh

def netsh(arguments=None):
    return baxh("netsh",arguments)