from ..bin.baxh import baxh

def explorer(arguments=None):
     return baxh("explorer",arguments)