from ..bin.baxh import baxh

def rasphone(arguments=None):
    return baxh("rasphone",arguments)