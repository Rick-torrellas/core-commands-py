from ..bin.baxh import baxh

def doskey(arguments=None):
     return baxh("doskey",arguments)