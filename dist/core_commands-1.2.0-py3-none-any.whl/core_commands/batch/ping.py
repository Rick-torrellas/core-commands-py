from ..bin.baxh import baxh

def ping(arguments=None):
    return baxh("ping",arguments)