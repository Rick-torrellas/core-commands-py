from ..bin.baxh import baxh

def runas(arguments=None):
    return baxh("runas",arguments)