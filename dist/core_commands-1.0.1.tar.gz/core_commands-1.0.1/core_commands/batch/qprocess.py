from ..bin.baxh import baxh

def qprocess(arguments=None):
    return baxh("qprocess",arguments)