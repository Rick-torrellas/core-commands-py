from ..bin.baxh import baxh

def icacls(arguments=None):
     return baxh("icacls",arguments)