from ..bin.baxh import baxh

def set(arguments=None):
    return baxh("set",arguments)