from ..bin.baxh import baxh

def hostname(arguments=None):
    return baxh("hostname",arguments)
