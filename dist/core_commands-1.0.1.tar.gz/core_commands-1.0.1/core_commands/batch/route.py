from ..bin.baxh import baxh

def route(arguments=None):
    return baxh("route",arguments)