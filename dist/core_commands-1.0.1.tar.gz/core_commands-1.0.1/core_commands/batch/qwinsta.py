from ..bin.baxh import baxh

def qwinsta(arguments=None):
    return baxh("qwinsta",arguments)