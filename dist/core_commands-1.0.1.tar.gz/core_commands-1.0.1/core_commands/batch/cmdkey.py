from ..bin.baxh import baxh

def cmdkey(arguments=None):
     return baxh("cmdkey",arguments)