from ..bin.baxh import baxh

def dism(arguments=None):
     return baxh("dism",arguments)