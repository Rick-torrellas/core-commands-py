from ..bin.baxh import baxh

def title(arguments=None):
    return baxh("title",arguments)