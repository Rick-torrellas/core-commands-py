from ..bin.baxh import baxh

def sleep(arguments=None):
    return baxh("sleep",arguments)