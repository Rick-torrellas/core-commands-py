from ..bin.baxh import baxh

def wecutil(arguments=None):
    return baxh("wecutil",arguments)