from ..bin.baxh import baxh

def taskkill(arguments=None):
    return baxh("taskkill",arguments)