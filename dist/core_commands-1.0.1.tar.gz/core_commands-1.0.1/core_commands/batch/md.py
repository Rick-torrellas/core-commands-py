from ..bin.baxh import baxh

def md(arguments=None):
    return baxh("md",arguments)