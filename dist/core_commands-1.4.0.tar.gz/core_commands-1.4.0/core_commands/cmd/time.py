from ..bin.cmd import cmd

def time(arguments=None):
    return cmd("time",arguments)