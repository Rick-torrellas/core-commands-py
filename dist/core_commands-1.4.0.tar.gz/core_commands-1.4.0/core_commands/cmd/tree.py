from ..bin.cmd import cmd

def tree(arguments=None):
    return cmd("tree",arguments)