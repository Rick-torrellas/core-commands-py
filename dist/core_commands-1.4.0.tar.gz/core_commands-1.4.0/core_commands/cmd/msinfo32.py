from ..bin.cmd import cmd

def msinfo32(arguments=None):
    return cmd('msinfo32',arguments)