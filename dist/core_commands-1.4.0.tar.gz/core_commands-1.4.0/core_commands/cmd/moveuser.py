from ..bin.cmd import cmd

def moveuser(arguments=None):
    return cmd("moveuser",arguments)