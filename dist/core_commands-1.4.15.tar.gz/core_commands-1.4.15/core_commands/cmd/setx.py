from ..bin.cmd import cmd

def setx(arguments=None):
    return cmd("setx",arguments)