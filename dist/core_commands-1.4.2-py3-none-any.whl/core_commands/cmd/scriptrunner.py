from ..bin.cmd import cmd

def scriptrunner(arguments=None):
    return cmd("scriptrunner",arguments)