from ..bin.cmd import cmd

def compact(arguments=None):
     return cmd("compact",arguments)