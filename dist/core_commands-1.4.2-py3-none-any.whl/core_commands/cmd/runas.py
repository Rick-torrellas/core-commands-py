from ..bin.cmd import cmd

def runas(arguments=None):
    return cmd("runas",arguments)