from ..bin.cmd import cmd

def rundll32(arguments=None):
    return cmd("rundll32",arguments)