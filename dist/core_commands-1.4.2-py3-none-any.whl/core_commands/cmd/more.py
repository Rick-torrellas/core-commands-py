from ..bin.cmd import cmd

def more(arguments=None):
    return cmd("more",arguments)