from ..bin.cmd import cmd

def explorer(arguments=None):
     return cmd("explorer",arguments)