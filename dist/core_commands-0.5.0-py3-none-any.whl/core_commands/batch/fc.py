from .command_cmd import basic_execution

def fc(arguments):
     return basic_execution("fc",arguments)