from .command_cmd import basic_execution

def rmtshare(arguments):
    return basic_execution("rmtshare",arguments)