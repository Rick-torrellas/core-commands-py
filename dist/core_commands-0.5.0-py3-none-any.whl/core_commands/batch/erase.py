from .command_cmd import basic_execution

def erase(arguments):
     return basic_execution("erase",arguments)