from .command_cmd import basic_execution

def reset(arguments):
    return basic_execution("reset",arguments)