from .command_cmd import basic_execution

def prompt(arguments):
    return basic_execution('propmt',arguments)