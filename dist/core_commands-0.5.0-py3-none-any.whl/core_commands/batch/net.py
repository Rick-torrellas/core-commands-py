from .command_cmd import basic_execution

def net(arguments):
    return basic_execution("net",arguments)