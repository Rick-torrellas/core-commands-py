from .command_cmd import basic_execution

def ssh(arguments):
    return basic_execution("ssh",arguments)