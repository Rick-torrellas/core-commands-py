from .command_cmd import basic_execution

def gpresult(arguments):
     return basic_execution("gpresult",arguments)