from .command_cmd import basic_execution

def tskill(arguments):
    return basic_execution("tskill",arguments)