from .command_cmd import basic_execution

def robocopy(arguments):
    return basic_execution("robocopy",arguments)