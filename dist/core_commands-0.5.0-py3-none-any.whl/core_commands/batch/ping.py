from .command_cmd import basic_execution

def ping(arguments):
    return basic_execution("ping",arguments)