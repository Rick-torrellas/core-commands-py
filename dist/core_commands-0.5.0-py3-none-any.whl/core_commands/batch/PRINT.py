from .command_cmd import basic_execution

def PRINT(arguments):
    return basic_execution("print",arguments)