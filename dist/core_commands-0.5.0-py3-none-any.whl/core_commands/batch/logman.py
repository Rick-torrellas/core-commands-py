from .command_cmd import basic_execution

def logman(arguments):
     return basic_execution("logman",arguments)