from .command_cmd import basic_execution

def pause(arguments):
    return basic_execution('pause',arguments)