from .command_cmd import basic_execution

def regsvr32(arguments):
    return basic_execution("regsvr32",arguments)