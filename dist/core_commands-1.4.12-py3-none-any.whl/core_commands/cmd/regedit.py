from ..bin.cmd import cmd

def regedit(arguments=None):
    return cmd("regedit",arguments)