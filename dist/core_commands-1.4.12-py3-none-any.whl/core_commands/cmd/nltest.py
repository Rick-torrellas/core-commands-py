from ..bin.cmd import cmd

def nltest(arguments=None):
    return cmd("nltest",arguments)