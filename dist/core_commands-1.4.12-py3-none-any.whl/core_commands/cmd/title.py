from ..bin.cmd import cmd

def title(arguments=None):
    return cmd("title",arguments)