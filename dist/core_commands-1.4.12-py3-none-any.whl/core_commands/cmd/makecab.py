from ..bin.cmd import cmd

def makecab(arguments=None):
    return cmd("makecab",arguments)