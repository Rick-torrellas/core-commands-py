from ..bin.cmd import cmd

def dsregcmd(arguments=None):
     return cmd("dsregcmd",arguments)