from ..bin.cmd import cmd

def verify(arguments=None):
    return cmd("verify",arguments)
