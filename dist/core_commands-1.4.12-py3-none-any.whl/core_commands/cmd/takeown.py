from ..bin.cmd import cmd

def takeown(arguments=None):
    return cmd("takeown",arguments)