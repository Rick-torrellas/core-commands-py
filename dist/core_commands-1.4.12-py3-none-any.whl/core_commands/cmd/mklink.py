from ..bin.cmd import cmd

def mklink(arguments=None):
    return cmd("mklink",arguments)