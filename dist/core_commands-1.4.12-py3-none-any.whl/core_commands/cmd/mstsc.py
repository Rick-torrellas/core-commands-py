from ..bin.cmd import cmd

def mstsc(arguments=None):
    return cmd("mstsc",arguments)