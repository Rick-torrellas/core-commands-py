from ..bin.cmd import cmd

def rasdial(arguments=None):
    return cmd("rasdial",arguments)