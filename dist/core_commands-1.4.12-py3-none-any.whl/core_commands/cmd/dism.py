from ..bin.cmd import cmd

def dism(arguments=None):
     return cmd("dism",arguments)