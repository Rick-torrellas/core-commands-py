from ..bin.cmd import cmd

def tracert(arguments=None):
    return cmd("tracert",arguments)