from ..bin.cmd import cmd

def pnputil(arguments=None):
    return cmd("pnputil",arguments)