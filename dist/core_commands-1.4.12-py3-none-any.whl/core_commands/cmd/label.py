from ..bin.cmd import cmd

def label(arguments=None):
     return cmd("label",arguments)