from ..bin.cmd import cmd

def forfiles(arguments=None):
     return cmd("forfiles",arguments)