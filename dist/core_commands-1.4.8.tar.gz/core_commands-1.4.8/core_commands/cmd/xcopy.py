from ..bin.cmd import cmd

def xcopy(arguments=None):
    return cmd("xcopy",arguments)