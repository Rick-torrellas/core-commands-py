from ..bin.cmd import cmd

def tar(arguments=None):
    return cmd("tar",arguments)