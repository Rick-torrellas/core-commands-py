from ..bin.cmd import cmd

def wpr(arguments=None):
    return cmd(f"wpr",arguments)