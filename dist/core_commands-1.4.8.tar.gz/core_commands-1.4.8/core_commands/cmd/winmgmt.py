
from ..bin.cmd import cmd

def winmgmt(arguments=None):
    return cmd("winmgmt",arguments)