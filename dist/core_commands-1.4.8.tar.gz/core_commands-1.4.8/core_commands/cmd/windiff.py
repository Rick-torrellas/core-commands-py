from ..bin.cmd import cmd

def windiff(arguments=None):
    return cmd(f"windiff",arguments)