from ..bin.cmd import cmd

def qappsrb(arguments=None):
    return cmd("gappsrb",arguments)