from ..bin.cmd import cmd

def getmac(arguments=None):
     return cmd("getmac",arguments)