from ..bin.cmd import cmd

def BREAK(arguments = None):
    return cmd('break', f"{arguments}") 