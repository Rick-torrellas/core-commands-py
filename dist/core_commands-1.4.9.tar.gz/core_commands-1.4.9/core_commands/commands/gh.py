from ..bin._command import _command

def gh(arguments=None):
    return _command("gh",arguments)