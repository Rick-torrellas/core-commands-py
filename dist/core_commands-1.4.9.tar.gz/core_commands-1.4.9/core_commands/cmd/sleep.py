from ..bin.cmd import cmd

def sleep(arguments=None):
    return cmd("sleep",arguments)