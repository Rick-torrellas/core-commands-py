from ..bin.baxh import baxh

def pushd(arguments=None):
    return baxh("pushd",arguments)