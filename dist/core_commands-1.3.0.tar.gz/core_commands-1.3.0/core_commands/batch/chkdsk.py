from ..bin.baxh import baxh

def chkdsk(arguments=None):
     return baxh("chkdsk",arguments)