from ..bin.baxh import baxh

def shutdown(arguments=None):
    return baxh("shutdown",arguments)