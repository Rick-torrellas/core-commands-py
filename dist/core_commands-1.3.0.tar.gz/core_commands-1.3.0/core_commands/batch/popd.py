from ..bin.baxh import baxh

def popd(arguments=None):
    return baxh("popd",arguments)