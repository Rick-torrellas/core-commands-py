from ..bin.baxh import baxh

def logoff(arguments=None):
    return baxh("logoff",arguments)