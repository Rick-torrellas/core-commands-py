from ..bin.baxh import baxh

def tree(arguments=None):
    return baxh("tree",arguments)