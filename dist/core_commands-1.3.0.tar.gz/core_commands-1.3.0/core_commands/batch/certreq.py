from ..bin.baxh import baxh

def certreq(arguments =None):
     return baxh("certreq",f'{arguments}') 