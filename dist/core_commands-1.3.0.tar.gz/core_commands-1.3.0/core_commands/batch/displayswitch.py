from ..bin.baxh import baxh

def displayswitch(arguments=None):
     return baxh("displayswitch",arguments)