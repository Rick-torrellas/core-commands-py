from ..bin.baxh import baxh

def convert(arguments=None):
     return baxh("convert",arguments)