from ..bin.baxh import baxh

def comp(arguments=None):
     return baxh("comp",arguments)