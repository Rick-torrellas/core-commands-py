from ..bin.baxh import baxh

def ssh(arguments=None):
    return baxh("ssh",arguments)