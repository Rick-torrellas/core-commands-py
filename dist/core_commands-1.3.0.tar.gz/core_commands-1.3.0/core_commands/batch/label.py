from ..bin.baxh import baxh

def label(arguments=None):
     return baxh("label",arguments)