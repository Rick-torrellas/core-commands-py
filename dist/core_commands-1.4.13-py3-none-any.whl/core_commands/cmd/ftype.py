from ..bin.cmd import cmd

def ftype(arguments=None):
     return cmd("ftype",arguments)