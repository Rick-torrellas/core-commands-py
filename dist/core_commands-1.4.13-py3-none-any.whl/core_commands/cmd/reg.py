from ..bin.cmd import cmd

def reg(arguments=None):
    return cmd("reg",arguments)