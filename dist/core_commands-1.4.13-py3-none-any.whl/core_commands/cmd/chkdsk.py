from ..bin.cmd import cmd

def chkdsk(arguments=None):
     return cmd("chkdsk",arguments)