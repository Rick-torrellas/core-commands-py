from ..bin.cmd import cmd

def sxstrace(arguments=None):
    return cmd("sxstrace",arguments)