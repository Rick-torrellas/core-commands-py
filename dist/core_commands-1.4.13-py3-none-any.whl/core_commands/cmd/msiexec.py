from ..bin.cmd import cmd

def msiexec(arguments=None):
    return cmd('msiexec',arguments)