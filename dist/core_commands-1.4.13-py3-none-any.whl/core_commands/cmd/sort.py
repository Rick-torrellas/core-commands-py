from ..bin.cmd import cmd

def sort(arguments=None):
    return cmd("sort",arguments)