from ..bin.cmd import cmd

def sc(arguments=None):
    return cmd("sc",arguments)