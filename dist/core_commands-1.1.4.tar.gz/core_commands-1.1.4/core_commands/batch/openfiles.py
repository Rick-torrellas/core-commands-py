from ..bin.baxh import baxh

def openfiles(arguments=None):
    return baxh("openfiles",arguments)