from ..bin.baxh import baxh

# TODO: este comando es mas profundo

def bcdboot(arguments = None):
    return baxh(f"bcdboot",f"{arguments}")