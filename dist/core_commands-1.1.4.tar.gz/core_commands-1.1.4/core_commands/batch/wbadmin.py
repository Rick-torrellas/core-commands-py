from ..bin.baxh import baxh

def wbadmin(arguments=None):
    return baxh(f"wbadmin {arguments}")