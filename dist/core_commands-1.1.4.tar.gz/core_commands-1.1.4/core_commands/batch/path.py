from ..bin.baxh import baxh

def path(arguments=None):
    return baxh("path",arguments)