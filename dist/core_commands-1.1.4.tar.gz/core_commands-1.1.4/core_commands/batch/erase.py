from ..bin.baxh import baxh

def erase(arguments=None):
     return baxh("erase",arguments)