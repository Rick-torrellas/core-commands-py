from ..bin.baxh import baxh

def more(arguments=None):
    return baxh("more",arguments)