from ..bin.baxh import baxh

def defrag(arguments=None):
     return baxh("defrag",arguments)