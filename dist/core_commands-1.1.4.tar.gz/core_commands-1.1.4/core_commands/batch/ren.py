from ..bin.baxh import baxh

def ren(arguments=None):
    return baxh("ren",arguments)