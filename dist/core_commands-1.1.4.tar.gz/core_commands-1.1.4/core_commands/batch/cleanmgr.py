from ..bin.baxh import baxh

def cleanmgr(arguments=None):
     return baxh("cleanmgr",arguments)