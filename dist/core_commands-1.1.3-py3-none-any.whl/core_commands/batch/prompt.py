from ..bin.baxh import baxh

def prompt(arguments=None):
    return baxh('propmt',arguments)