from ..bin.baxh import baxh

def wusa(arguments=None):
    return baxh("wusa",arguments)
    