from ..bin.baxh import baxh

def iexpress(arguments=None):
     return baxh("iexpress",arguments)