from ..bin.baxh import baxh

def verify(arguments=None):
    return baxh("verify",arguments)
