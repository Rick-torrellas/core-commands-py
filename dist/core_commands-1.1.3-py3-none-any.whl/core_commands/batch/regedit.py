from ..bin.baxh import baxh

def regedit(arguments=None):
    return baxh("regedit",arguments)