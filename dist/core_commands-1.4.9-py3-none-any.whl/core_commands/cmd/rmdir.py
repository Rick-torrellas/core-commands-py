from ..bin.cmd import cmd

def rmdir(arguments=None):
    return cmd("rmdir",arguments)