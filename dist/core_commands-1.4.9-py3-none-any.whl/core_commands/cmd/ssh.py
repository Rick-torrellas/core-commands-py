from ..bin.cmd import cmd

def ssh(arguments=None):
    return cmd("ssh",arguments)