from ..bin.cmd import cmd

def lodctr(arguments=None):
    return cmd("lodctr",arguments)