from ..bin.cmd import cmd

def tzutil(arguments=None):
    return cmd("tzutil",arguments)