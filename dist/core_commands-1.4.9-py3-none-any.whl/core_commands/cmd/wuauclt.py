from ..bin.cmd import cmd

def wuauclt(arguments = None):
    return cmd('wuauclt',arguments)