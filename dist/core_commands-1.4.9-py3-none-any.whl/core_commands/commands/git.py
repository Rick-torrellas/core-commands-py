from ..bin.baxh import baxh

def git(arguments=None):
    return baxh("git",arguments)
