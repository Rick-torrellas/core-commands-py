from ..bin.baxh import baxh

def forfiles(arguments=None):
     return baxh("forfiles",arguments)