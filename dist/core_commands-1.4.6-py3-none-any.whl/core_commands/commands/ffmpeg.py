from ..bin._command import _command

def ffmpeg(arguments):
    return _command('ffmpeg', arguments)