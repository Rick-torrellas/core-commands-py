from ..bin.cmd import cmd

def format(arguments=None):
     return cmd("format",arguments)