from ..bin.cmd import cmd

def prompt(arguments=None):
    return cmd('propmt',arguments)