from ..bin.cmd import cmd

def start(arguments=None):
    return cmd("start",arguments)