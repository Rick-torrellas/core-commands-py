from ..bin.cmd import cmd

def cmdkey(arguments=None):
     return cmd("cmdkey",arguments)