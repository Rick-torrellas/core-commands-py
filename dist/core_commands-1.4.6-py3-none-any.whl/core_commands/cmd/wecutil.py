from ..bin.cmd import cmd

def wecutil(arguments=None):
    return cmd("wecutil",arguments)