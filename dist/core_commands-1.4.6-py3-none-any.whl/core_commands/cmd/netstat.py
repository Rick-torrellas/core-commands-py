from ..bin.cmd import cmd

def netstat(arguments=None):
    return cmd("netstat",arguments)