from ..bin.cmd import cmd

def nslookup(arguments=None):
    return cmd("nslookup",arguments)