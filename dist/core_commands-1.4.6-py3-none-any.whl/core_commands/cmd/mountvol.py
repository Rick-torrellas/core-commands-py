from ..bin.cmd import cmd

def mountvol(arguments=None):
    return cmd("mountvol",arguments)