from ..bin.cmd import cmd

def qprocess(arguments=None):
    return cmd("qprocess",arguments)