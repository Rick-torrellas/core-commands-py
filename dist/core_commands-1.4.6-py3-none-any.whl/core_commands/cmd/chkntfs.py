from ..bin.cmd import cmd

def chkntfs(arguments=None):
     return cmd("chkntfs",arguments)