from ..bin.cmd import cmd

def route(arguments=None):
    return cmd("route",arguments)