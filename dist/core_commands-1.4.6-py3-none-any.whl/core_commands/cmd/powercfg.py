from ..bin.cmd import cmd

def powercfg(arguments=None):
    return cmd("powercfg",arguments)