from .command_cmd import basic_execution

def compact(arguments):
     return basic_execution("compact",arguments)