from .command_cmd import basic_execution

def doskey(arguments):
     return basic_execution("doskey",arguments)