from .command_cmd import basic_execution

def esentutl(arguments):
     return basic_execution("esentutl",arguments)