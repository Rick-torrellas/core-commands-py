from .command_cmd import command_cmd

# TODO: profundo
def bitsadmin(arguments):
    return command_cmd(f"bitsadmin {arguments}")