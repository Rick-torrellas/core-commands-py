from .command_cmd import basic_execution

def mstsc(arguments):
    return basic_execution("mstsc",arguments)