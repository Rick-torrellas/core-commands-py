from .command_cmd import basic_execution

def slmgr(arguments):
    return basic_execution("slmgr",arguments)