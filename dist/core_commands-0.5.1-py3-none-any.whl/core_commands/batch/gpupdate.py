from .command_cmd import basic_execution

def gpupdate(arguments):
     return basic_execution("gpupdate",arguments)