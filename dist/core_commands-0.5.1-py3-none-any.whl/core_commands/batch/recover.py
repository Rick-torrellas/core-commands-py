from .command_cmd import basic_execution

def recover(arguments):
    return basic_execution("recover",arguments)