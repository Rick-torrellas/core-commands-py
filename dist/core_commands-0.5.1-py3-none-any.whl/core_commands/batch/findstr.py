from .command_cmd import basic_execution

def findstr(arguments):
     return basic_execution("findstr",arguments)