from .command_cmd import basic_execution

def regini(arguments):
    return basic_execution("regini",arguments)