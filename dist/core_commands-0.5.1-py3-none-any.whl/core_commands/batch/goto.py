from .command_cmd import basic_execution

def goto(arguments):
     return basic_execution("goto",arguments)