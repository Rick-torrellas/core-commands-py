from .command_cmd import basic_execution

def pushd(arguments):
    return basic_execution("pushd",arguments)