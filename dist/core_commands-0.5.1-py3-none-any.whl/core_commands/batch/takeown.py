from .command_cmd import basic_execution

def takeown(arguments):
    return basic_execution("takeown",arguments)