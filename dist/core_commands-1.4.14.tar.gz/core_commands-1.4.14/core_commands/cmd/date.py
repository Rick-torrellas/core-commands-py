from ..bin.cmd import cmd

def date(arguments=None):
    return cmd('date',arguments)