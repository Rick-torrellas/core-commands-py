from ..bin.cmd import cmd

def schtasks(arguments=None):
    return cmd("schtasks",arguments)