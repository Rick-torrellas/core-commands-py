from ..bin.cmd import cmd

def EXIT(arguments=None):
     return cmd("exit",arguments)