from ..bin.cmd import cmd

def cleanmgr(arguments=None):
     return cmd("cleanmgr",arguments)