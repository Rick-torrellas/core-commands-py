from ..bin.baxh import baxh

def findstr(arguments=None):
     return baxh("findstr",arguments)