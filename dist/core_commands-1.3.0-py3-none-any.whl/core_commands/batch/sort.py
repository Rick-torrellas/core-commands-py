from ..bin.baxh import baxh

def sort(arguments=None):
    return baxh("sort",arguments)