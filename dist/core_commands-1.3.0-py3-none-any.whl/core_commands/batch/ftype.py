from ..bin.baxh import baxh

def ftype(arguments=None):
     return baxh("ftype",arguments)