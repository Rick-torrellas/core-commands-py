from ..bin.baxh import baxh

def help(arguments=None):
     return baxh("help",arguments)