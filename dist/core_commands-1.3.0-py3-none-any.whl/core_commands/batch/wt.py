from ..bin.baxh import baxh

def wt(arguments=None):
    return baxh("wt",arguments)