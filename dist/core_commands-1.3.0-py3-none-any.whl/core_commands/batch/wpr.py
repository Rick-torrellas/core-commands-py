from ..bin.baxh import baxh

def wpr(arguments=None):
    return baxh(f"wpr",arguments)