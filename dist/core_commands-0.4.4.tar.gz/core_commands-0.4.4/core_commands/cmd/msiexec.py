from .command_cmd import basic_execution

def msiexec(arguments):
    return basic_execution('msiexec',arguments)