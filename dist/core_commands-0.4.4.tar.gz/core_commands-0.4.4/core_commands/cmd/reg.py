from .command_cmd import basic_execution

def reg(arguments):
    return basic_execution("reg",arguments)