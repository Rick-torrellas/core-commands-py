from .command_cmd import command_cmd

def cls():
    command_cmd("cls")