from .command_cmd import basic_execution

def setx(arguments):
    return basic_execution("setx",arguments)