from .command_cmd import basic_execution

def find(arguments):
     return basic_execution("find",arguments)