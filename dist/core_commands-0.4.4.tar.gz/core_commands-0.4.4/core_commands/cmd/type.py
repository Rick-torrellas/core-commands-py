from .command_cmd import basic_execution

def type(arguments):
    basic_execution("type",arguments)