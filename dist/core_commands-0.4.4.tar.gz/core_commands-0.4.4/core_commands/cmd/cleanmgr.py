from .command_cmd import basic_execution

def cleanmgr(arguments):
     return basic_execution("cleanmgr",arguments)