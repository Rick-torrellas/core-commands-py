from .command_cmd import basic_execution

def qwinsta(arguments):
    return basic_execution("qwinsta",arguments)