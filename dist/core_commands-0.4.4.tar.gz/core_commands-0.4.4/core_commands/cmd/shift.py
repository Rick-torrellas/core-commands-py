from .command_cmd import basic_execution

def shift(arguments):
    return basic_execution("shift",arguments)