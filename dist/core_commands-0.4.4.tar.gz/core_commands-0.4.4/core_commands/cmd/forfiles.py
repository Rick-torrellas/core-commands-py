from .command_cmd import basic_execution

def forfiles(arguments):
     return basic_execution("forfiles",arguments)