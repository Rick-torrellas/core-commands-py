from .command_cmd import basic_execution

def mklink(arguments):
    return basic_execution("mklink",arguments)