from .command_cmd import basic_execution

def qprocess(arguments):
    return basic_execution("qprocess",arguments)