from .command_cmd import basic_execution

def set(arguments):
    return basic_execution("set",arguments)