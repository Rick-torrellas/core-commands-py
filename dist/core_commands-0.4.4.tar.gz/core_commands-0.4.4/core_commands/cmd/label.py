from .command_cmd import basic_execution

def label(arguments):
     return basic_execution("label",arguments)