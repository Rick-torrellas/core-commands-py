from .command_cmd import basic_execution

def format(arguments):
     return basic_execution("format",arguments)