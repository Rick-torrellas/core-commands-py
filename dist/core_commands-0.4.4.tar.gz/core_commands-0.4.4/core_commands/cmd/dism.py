from .command_cmd import basic_execution

def dism(arguments):
     return basic_execution("dism",arguments)