from ..bin.baxh import baxh

def sc(arguments=None):
    return baxh("sc",arguments)