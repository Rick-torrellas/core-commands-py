from ..bin.baxh import baxh

def pause(arguments=None):
    return baxh('pause',arguments)