from ..bin.baxh import baxh

def clip(arguments=None):
     return baxh("clip",arguments)