from ..bin.baxh import baxh

def start(arguments=None):
    return baxh("start",arguments)