from ..bin.baxh import baxh

def regini(arguments=None):
    return baxh("regini",arguments)