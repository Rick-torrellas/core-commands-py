from ..bin.baxh import baxh

def powercfg(arguments=None):
    return baxh("powercfg",arguments)