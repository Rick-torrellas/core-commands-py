from ..bin.baxh import baxh

def FOR(arguments = None):
     return baxh("for",arguments)