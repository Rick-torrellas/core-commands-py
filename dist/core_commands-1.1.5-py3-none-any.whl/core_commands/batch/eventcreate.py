from ..bin.baxh import baxh

def eventcreate(arguments=None):
     return baxh("eventcreate",arguments)