from ..bin.baxh import baxh

# TODO: profundo
def bitsadmin(arguments = None):
    return baxh(f"bitsadmin",f"{arguments}")