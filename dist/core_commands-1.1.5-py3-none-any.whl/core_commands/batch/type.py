from ..bin.baxh import baxh

def type(arguments=None):
    baxh("type",arguments)