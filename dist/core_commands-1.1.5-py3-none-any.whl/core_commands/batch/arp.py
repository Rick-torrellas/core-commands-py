from ..bin.baxh import baxh

def arp(arguments = None):
    return baxh("arp",f"{arguments}")