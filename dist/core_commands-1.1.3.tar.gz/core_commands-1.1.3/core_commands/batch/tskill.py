from ..bin.baxh import baxh

def tskill(arguments=None):
    return baxh("tskill",arguments)