from ..bin.baxh import baxh

def whoami(arguments = None):
    return baxh("whoami",arguments)
