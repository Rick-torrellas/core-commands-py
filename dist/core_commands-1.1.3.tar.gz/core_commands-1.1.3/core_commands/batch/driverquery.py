from ..bin.baxh import baxh

def driverquery(arguments=None):
     return baxh("driverquery",arguments)