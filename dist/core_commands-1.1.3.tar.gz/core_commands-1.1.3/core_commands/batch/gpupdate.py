from ..bin.baxh import baxh

def gpupdate(arguments=None):
     return baxh("gpupdate",arguments)