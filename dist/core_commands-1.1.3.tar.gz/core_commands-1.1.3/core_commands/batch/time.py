from ..bin.baxh import baxh

def time(arguments=None):
    return baxh("time",arguments)