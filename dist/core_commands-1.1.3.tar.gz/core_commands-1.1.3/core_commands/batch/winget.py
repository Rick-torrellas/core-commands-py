from ..bin.baxh import baxh

def winget(arguments=None):
    return baxh(f"winget",arguments)