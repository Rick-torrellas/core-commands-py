from ..bin.baxh import baxh

def wuauclt(arguments = None):
    return baxh('wuauclt',arguments)