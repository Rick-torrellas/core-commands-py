from ..bin.baxh import baxh

def schtasks(arguments=None):
    return baxh("schtasks",arguments)