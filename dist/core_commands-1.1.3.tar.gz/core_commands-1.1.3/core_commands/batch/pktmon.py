from ..bin.baxh import baxh

def pktmon(arguments=None):
    return baxh("pktmon",arguments)