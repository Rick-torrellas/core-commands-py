from ..bin.baxh import baxh

def fsutil(arguments=None):
     return baxh("fsutil",arguments)