from ..bin.baxh import baxh

def chcp(arguments=None):
     return baxh("chcp",f"{arguments}")