from ..bin.baxh import baxh

def wevtutil(arguments=None):
    return baxh(f"wevtutil {arguments}")