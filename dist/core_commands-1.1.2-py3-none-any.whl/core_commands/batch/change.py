from ..bin.baxh import baxh

def change(arguments = None):
     return baxh("change",f"{arguments}")