from ..bin.baxh import baxh

def PRINT(arguments=None):
    return baxh("print",arguments)