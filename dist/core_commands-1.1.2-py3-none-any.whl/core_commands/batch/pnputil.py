from ..bin.baxh import baxh

def pnputil(arguments=None):
    return baxh("pnputil",arguments)