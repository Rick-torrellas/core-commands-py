from ..bin.baxh import baxh

def mstsc(arguments=None):
    return baxh("mstsc",arguments)