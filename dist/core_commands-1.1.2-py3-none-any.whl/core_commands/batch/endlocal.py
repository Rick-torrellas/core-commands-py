from ..bin.baxh import baxh

def endlocal(arguments=None):
     return baxh("endlocal",arguments)