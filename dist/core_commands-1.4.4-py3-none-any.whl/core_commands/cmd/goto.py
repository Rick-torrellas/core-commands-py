from ..bin.cmd import cmd

def goto(arguments=None):
     return cmd("goto",arguments)