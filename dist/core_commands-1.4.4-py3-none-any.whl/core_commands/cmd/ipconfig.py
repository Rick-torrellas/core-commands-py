from ..bin.cmd import cmd

def ipconfig(arguments=None):
     return cmd("ipconfig",arguments)