from ..bin.cmd import cmd

def find(arguments=None):
     return cmd("find",arguments)