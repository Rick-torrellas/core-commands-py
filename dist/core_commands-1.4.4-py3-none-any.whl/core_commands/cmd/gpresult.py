from ..bin.cmd import cmd

def gpresult(arguments=None):
     return cmd("gpresult",arguments)