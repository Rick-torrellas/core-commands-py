from ..bin.cmd import cmd

def wmic(arguments=None):
    return cmd("wmic",arguments)