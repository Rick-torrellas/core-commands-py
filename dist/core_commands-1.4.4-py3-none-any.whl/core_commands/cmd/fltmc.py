from ..bin.cmd import cmd

def fltmc(arguments=None):
     return cmd("fltmc",arguments)