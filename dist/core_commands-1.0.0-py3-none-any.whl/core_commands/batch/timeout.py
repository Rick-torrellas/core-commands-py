from ..bin.baxh import baxh

def timeout(arguments=None):
    return baxh("timeout",arguments)