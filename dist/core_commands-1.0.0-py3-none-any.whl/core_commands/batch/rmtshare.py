from ..bin.baxh import baxh

def rmtshare(arguments=None):
    return baxh("rmtshare",arguments)