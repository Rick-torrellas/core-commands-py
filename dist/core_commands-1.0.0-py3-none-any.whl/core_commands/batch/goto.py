from ..bin.baxh import baxh

def goto(arguments=None):
     return baxh("goto",arguments)