from ..bin.baxh import baxh

def sxstrace(arguments=None):
    return baxh("sxstrace",arguments)