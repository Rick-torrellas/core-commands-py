from ..bin.baxh import baxh

def nslookup(arguments=None):
    return baxh("nslookup",arguments)