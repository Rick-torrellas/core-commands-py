from ..bin.baxh import baxh

def shift(arguments=None):
    return baxh("shift",arguments)