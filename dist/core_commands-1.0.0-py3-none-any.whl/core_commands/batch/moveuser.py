from ..bin.baxh import baxh

def moveuser(arguments=None):
    return baxh("moveuser",arguments)