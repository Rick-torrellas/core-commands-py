from ..bin.baxh import baxh

def nbtstat(arguments=None):
    return baxh("nbtstat",arguments)

