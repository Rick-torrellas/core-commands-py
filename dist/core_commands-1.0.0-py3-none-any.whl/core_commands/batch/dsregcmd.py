from ..bin.baxh import baxh

def dsregcmd(arguments=None):
     return baxh("dsregcmd",arguments)