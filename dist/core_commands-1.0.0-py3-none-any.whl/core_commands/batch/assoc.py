from ..bin.baxh import baxh

def assoc(arguments = None):
    return baxh("assoc",f"{arguments}")