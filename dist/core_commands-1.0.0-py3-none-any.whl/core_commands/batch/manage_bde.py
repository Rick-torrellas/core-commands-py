from ..bin.baxh import baxh

def manage_bde(arguments=None):
    return baxh("manage-bde",arguments)  