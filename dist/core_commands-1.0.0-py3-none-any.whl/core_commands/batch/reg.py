from ..bin.baxh import baxh

def reg(arguments=None):
    return baxh("reg",arguments)