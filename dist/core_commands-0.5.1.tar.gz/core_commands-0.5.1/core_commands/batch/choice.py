from .command_cmd import basic_execution

def choice(arguments):
     return basic_execution("choice",arguments)