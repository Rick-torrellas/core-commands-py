from .command_cmd import basic_execution

def driverquery(arguments):
     return basic_execution("driverquery",arguments)