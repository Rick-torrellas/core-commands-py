from .command_cmd import basic_execution

def ipconfig(arguments):
     return basic_execution("ipconfig",arguments)