from .command_cmd import basic_execution

def getmac(arguments):
     return basic_execution("getmac",arguments)