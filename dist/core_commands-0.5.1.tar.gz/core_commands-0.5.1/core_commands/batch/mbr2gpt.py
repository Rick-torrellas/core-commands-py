from .command_cmd import basic_execution

def mbr2gpt(arguments):
    return basic_execution("mbr2gpt",arguments)