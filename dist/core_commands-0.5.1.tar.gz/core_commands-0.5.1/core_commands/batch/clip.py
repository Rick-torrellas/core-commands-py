from .command_cmd import basic_execution

def clip(arguments):
     return basic_execution("clip",arguments)