from .command_cmd import basic_execution

def mountvol(arguments):
    return basic_execution("mountvol",arguments)