from .command_cmd import basic_execution

def runas(arguments):
    return basic_execution("runas",arguments)