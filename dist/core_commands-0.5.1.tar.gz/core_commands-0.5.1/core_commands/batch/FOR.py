from .command_cmd import basic_execution

def FOR(arguments):
     return basic_execution("for",arguments)