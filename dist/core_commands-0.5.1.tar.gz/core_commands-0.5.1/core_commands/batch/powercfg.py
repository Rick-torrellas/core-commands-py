from .command_cmd import basic_execution

def powercfg(arguments):
    return basic_execution("powercfg",arguments)