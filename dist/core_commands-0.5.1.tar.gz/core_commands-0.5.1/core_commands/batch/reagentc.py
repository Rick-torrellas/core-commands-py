from .command_cmd import basic_execution

def reagentc(arguments):
    return basic_execution("reagentc",arguments)