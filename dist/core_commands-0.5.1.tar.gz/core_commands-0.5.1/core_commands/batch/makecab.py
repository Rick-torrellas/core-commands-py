from .command_cmd import basic_execution

def makecab(arguments):
    return basic_execution("makecab",arguments)