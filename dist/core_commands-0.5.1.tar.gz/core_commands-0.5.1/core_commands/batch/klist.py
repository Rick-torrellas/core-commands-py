from .command_cmd import basic_execution

def klist(arguments):
     return basic_execution("klist",arguments)