from .command_cmd import basic_execution

def tracert(arguments):
    return basic_execution("tracert",arguments)