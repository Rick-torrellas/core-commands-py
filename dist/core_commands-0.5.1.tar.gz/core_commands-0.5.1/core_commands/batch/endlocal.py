from .command_cmd import basic_execution

def endlocal(arguments):
     return basic_execution("endlocal",arguments)