from .command_cmd import basic_execution

def sleep(arguments):
    return basic_execution("sleep",arguments)