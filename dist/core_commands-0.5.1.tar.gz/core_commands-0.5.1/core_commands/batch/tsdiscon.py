from .command_cmd import basic_execution

def tsdiscon(arguments):
    return basic_execution("tsdiscon",arguments)