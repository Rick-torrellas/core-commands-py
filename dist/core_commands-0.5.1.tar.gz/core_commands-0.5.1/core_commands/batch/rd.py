from .command_cmd import basic_execution

def rd(arguments):
    return basic_execution("rd",arguments)