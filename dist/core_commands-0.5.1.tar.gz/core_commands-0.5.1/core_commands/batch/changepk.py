from .command_cmd import basic_execution

def changepk(arguments):
     return basic_execution("changepk",arguments)