from ..bin.cmd import cmd

def defrag(arguments=None):
     return cmd("defrag",arguments)