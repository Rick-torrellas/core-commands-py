from ..bin.cmd import cmd

def replace(arguments=None):
    return cmd("replace",arguments)