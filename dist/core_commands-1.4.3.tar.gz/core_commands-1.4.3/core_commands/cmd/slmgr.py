from ..bin.cmd import cmd

def slmgr(arguments=None):
    return cmd("slmgr",arguments)