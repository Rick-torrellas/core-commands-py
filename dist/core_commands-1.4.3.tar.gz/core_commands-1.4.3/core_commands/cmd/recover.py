from ..bin.cmd import cmd

def recover(arguments=None):
    return cmd("recover",arguments)