from ..bin.cmd import cmd

def nbtstat(arguments=None):
    return cmd("nbtstat",arguments)

