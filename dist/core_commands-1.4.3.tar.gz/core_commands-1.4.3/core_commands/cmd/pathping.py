from ..bin.cmd import cmd

def pathping(arguments=None):
    return cmd("pathping",arguments)