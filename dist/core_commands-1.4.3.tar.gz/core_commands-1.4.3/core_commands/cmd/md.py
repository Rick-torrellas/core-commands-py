from ..bin.cmd import cmd

def md(arguments=None):
    return cmd("md",arguments)