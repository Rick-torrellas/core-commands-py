from ..bin.cmd import cmd

def type(arguments=None):
    baxh("type",arguments)