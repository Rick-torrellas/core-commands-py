from ..bin.cmd import cmd

def mode(arguments=None):
    return cmd("mode",arguments)