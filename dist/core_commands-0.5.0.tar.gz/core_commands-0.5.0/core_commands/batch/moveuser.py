from .command_cmd import basic_execution

def moveuser(arguments):
    return basic_execution("moveuser",arguments)