from .command_cmd import basic_execution

def sort(arguments):
    return basic_execution("sort",arguments)