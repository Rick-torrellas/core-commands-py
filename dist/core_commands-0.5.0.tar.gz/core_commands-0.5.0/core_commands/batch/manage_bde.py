from .command_cmd import basic_execution

def manage_bde(arguments):
    return basic_execution("manage-bde",arguments)  