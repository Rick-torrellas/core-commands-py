from .command_cmd import basic_execution

def certreq(arguments):
     return basic_execution("certreq",arguments)