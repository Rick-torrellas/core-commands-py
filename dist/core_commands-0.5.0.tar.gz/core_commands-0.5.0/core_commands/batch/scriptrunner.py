from .command_cmd import basic_execution

def scriptrunner(arguments):
    return basic_execution("scriptrunner",arguments)