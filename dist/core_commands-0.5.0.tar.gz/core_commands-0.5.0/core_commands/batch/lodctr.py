from .command_cmd import basic_execution

def lodctr(arguments):
    return basic_execution("lodctr",arguments)