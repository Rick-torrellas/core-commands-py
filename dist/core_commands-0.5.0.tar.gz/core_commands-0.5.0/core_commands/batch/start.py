from .command_cmd import basic_execution

def start(arguments = False):
    return basic_execution("start",arguments)