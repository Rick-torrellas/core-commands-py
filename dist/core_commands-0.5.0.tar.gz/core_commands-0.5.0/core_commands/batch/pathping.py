from .command_cmd import basic_execution

def pathping(arguments):
    return basic_execution("pathping",arguments)