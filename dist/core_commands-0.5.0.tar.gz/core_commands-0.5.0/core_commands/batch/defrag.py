from .command_cmd import basic_execution

def defrag(arguments):
     return basic_execution("defrag",arguments)