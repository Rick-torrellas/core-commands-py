from .command_cmd import basic_execution

def msg(arguments):
    return basic_execution("msg",arguments)