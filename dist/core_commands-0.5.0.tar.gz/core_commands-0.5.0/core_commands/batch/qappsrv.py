from .command_cmd import basic_execution

def qappsrb(arguments):
    return basic_execution("gappsrb",arguments)