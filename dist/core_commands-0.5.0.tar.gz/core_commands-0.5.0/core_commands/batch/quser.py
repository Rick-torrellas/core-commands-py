from .command_cmd import basic_execution

def quser(arguments):
    return basic_execution("quser",arguments)