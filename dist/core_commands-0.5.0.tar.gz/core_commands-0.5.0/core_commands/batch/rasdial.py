from .command_cmd import basic_execution

def rasdial(arguments):
    return basic_execution("rasdial",arguments)