from .command_cmd import basic_execution

def icacls(arguments):
     return basic_execution("icacls",arguments)