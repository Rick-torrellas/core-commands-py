from .command_cmd import basic_execution

def convert(arguments):
     return basic_execution("convert",arguments)