from ..bin.baxh import baxh

def msiexec(arguments=None):
    return baxh('msiexec',arguments)