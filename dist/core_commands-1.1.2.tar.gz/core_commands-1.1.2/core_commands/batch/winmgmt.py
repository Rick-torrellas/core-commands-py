
from ..bin.baxh import baxh

def winmgmt(arguments=None):
    return baxh("winmgmt",arguments)