from ..bin.baxh import baxh

def ver():
    return baxh("ver")