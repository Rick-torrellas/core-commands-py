from ..bin.baxh import baxh

def DEL(arguments=None):
    return baxh('del',arguments)
