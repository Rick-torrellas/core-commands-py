from ..bin.baxh import baxh

def pathping(arguments=None):
    return baxh("pathping",arguments)