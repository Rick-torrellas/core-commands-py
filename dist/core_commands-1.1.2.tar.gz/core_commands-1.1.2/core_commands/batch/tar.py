from ..bin.baxh import baxh

def tar(arguments=None):
    return baxh("tar",arguments)