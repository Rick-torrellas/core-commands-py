from ..bin.baxh import baxh

def exit(arguments=None):
     return baxh("exit",arguments)