from ..bin.baxh import baxh

def cls(arguments=None):
    baxh("cls",arguments)