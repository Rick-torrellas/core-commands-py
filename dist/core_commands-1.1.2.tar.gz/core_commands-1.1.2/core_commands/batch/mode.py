from ..bin.baxh import baxh

def mode(arguments=None):
    return baxh("mode",arguments)