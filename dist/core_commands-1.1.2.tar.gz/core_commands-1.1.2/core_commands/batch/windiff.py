from ..bin.baxh import baxh

def windiff(arguments=None):
    return baxh(f"windiff",arguments)