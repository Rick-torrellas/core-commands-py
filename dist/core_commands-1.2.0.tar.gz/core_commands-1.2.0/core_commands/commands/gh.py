from ..bin._command import _command

def gh(command,arguments=None):
    return _command(command,arguments)