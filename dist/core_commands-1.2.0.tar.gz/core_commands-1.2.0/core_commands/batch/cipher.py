from ..bin.baxh import baxh

def cipher(arguments=None):
     return baxh("cipher",arguments)