from ..bin.baxh import baxh

def reagentc(arguments=None):
    return baxh("reagentc",arguments)