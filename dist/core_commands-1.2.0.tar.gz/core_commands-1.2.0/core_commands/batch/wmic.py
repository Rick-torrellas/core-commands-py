from ..bin.baxh import baxh

def wmic(arguments=None):
    return baxh("wmic",arguments)