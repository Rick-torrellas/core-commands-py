from ..bin.baxh import baxh

def ipconfig(arguments=None):
     return baxh("ipconfig",arguments)