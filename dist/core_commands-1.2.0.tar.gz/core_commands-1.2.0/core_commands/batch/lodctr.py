from ..bin.baxh import baxh

def lodctr(arguments=None):
    return baxh("lodctr",arguments)