from ..bin.baxh import baxh

def format(arguments=None):
     return baxh("format",arguments)