from ..bin.baxh import baxh

def reset(arguments=None):
    return baxh("reset",arguments)