from ..bin.baxh import baxh

def esentutl(arguments=None):
     return baxh("esentutl",arguments)