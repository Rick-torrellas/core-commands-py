from ..bin.baxh import baxh

def recover(arguments=None):
    return baxh("recover",arguments)