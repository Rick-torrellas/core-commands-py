from ..bin.cmd import cmd

def erase(arguments=None):
     return cmd("erase",arguments)