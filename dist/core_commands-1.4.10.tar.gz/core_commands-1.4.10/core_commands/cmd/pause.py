from ..bin.cmd import cmd

def pause(arguments=None):
    return cmd('pause',arguments)