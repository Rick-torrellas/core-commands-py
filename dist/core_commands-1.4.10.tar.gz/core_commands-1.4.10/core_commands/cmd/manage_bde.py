from ..bin.cmd import cmd

def manage_bde(arguments=None):
    return cmd("manage-bde",arguments)  