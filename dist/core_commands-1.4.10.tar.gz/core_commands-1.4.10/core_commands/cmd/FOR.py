from ..bin.cmd import cmd

def FOR(arguments = None):
     return cmd("for",arguments)