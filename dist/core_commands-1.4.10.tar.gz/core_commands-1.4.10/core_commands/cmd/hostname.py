from ..bin.cmd import cmd

def hostname(arguments=None):
    return cmd("hostname",arguments)
