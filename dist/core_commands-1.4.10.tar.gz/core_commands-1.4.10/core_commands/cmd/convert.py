from ..bin.cmd import cmd

def convert(arguments=None):
     return cmd("convert",arguments)