from ..bin.cmd import cmd

def ren(arguments=None):
    return cmd("ren",arguments)