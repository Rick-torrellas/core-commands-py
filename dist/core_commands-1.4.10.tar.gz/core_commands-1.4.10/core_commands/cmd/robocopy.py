from ..bin.cmd import cmd

def robocopy(arguments=None):
    return cmd("robocopy",arguments)