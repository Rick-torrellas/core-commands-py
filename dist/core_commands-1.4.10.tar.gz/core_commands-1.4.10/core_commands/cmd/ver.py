from ..bin.cmd import cmd

def ver():
    return cmd("ver")