# from .cmd import ping
from ..bin.cmd import cmd
from ._ping import ping

__all__ = ['_ping',"cmd"]