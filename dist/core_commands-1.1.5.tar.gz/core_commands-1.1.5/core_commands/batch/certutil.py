from ..bin.baxh import baxh

def certutil(arguments = None):
     return baxh("certutil",f'{arguments}')