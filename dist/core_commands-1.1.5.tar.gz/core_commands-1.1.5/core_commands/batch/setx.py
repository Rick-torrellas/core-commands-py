from ..bin.baxh import baxh

def setx(arguments=None):
    return baxh("setx",arguments)