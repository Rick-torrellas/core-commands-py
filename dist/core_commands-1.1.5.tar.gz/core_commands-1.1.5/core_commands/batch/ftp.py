from ..bin.baxh import baxh

def ftp(arguments=None):
     return baxh("ftp",arguments)