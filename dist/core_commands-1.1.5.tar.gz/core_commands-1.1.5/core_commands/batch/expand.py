from ..bin.baxh import baxh

def expand(arguments=None):
     return baxh("expand",arguments)