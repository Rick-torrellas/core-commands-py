from ..bin.baxh import baxh

def xcopy(arguments=None):
    return baxh("xcopy",arguments)