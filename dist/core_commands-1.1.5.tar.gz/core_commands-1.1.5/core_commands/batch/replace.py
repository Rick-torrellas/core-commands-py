from ..bin.baxh import baxh

def replace(arguments=None):
    return baxh("replace",arguments)