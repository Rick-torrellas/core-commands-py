from ..bin.baxh import baxh

def BREAK(arguments = None):
    return baxh('break', f"{arguments}") 