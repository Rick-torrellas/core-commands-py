from ..bin.baxh import baxh

def systeminfo(arguments=None):
    return baxh("systeminfo",arguments)