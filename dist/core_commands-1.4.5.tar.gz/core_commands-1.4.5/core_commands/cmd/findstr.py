from ..bin.cmd import cmd

def findstr(arguments=None):
     return cmd("findstr",arguments)