from ..bin.cmd import cmd

def tskill(arguments=None):
    return cmd("tskill",arguments)