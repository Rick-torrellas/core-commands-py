from ..bin.cmd import cmd

def assoc(arguments = None):
    return cmd("assoc",f"{arguments}")