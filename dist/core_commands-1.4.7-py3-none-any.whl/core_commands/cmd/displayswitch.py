from ..bin.cmd import cmd

def displayswitch(arguments=None):
     return cmd("displayswitch",arguments)