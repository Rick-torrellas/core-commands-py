from ..bin.cmd import cmd

def vssadmin(arguments=None):
    return cmd("vssadmin",arguments)