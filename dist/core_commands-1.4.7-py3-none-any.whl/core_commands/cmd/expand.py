from ..bin.cmd import cmd

def expand(arguments=None):
     return cmd("expand",arguments)