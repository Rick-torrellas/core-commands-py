from ..bin.cmd import cmd

def tasklist(arguments=None):
    return cmd("tasklist",arguments)