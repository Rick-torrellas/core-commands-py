from ..bin.cmd import cmd

def rmtshare(arguments=None):
    return cmd("rmtshare",arguments)