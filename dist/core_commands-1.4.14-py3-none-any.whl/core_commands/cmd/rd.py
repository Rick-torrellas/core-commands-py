from ..bin.cmd import cmd

def rd(arguments=None):
    return cmd("rd",arguments)