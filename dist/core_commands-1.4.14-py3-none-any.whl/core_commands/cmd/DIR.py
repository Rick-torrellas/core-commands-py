from ..bin.cmd import cmd

def DIR(arguments = None):
    return cmd("dir",arguments)