from ..bin.cmd import cmd

def cipher(arguments=None):
     return cmd("cipher",arguments)