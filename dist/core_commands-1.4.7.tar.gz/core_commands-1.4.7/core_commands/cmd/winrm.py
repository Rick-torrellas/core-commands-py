from ..bin.cmd import cmd

def winrm(arguments=None):
    return cmd("winrm",arguments)