from ..bin.cmd import cmd

def regsvr32(arguments=None):
    return cmd("regsvr32",arguments)