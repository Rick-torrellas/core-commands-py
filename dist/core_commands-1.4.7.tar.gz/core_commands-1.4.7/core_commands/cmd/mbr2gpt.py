from ..bin.cmd import cmd

def mbr2gpt(arguments=None):
    return cmd("mbr2gpt",arguments)