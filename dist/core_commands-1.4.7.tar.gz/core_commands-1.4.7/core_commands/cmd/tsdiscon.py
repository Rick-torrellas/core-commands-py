from ..bin.cmd import cmd

def tsdiscon(arguments=None):
    return cmd("tsdiscon",arguments)