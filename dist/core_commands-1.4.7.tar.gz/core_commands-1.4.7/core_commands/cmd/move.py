from ..bin.cmd import cmd

def move(arguments=None):
    return cmd("move",arguments)