from ..bin.cmd import cmd

def typeperf(arguments=None):
    return cmd("typeperf",arguments)