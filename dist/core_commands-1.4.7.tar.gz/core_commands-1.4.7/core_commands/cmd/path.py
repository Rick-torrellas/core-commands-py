from ..bin.cmd import cmd

def path(arguments=None):
    return cmd("path",arguments)